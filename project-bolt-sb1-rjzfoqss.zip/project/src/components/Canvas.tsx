import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Settings2, Download, RefreshCw, Play, Pause } from 'lucide-react';

interface CanvasProps {
  width: number;
  height: number;
  showControls?: boolean;
  autoPlay?: boolean;
  className?: string;
}

export default function Canvas({ width, height, showControls = false, autoPlay = false, className = '' }: CanvasProps) {
  const [isPlaying, setIsPlaying] = useState(autoPlay);
  const [settings, setSettings] = useState({
    complexity: Math.random() * 40 + 30,
    speed: Math.random() * 0.5 + 0.2,
    color: `hsl(${Math.random() * 360}, 100%, 50%)`,
  });
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const generateArt = useCallback((ctx: CanvasRenderingContext2D) => {
    const width = ctx.canvas.width;
    const height = ctx.canvas.height;
    
    ctx.fillStyle = 'rgba(0, 0, 0, 0.1)';
    ctx.fillRect(0, 0, width, height);

    const time = Date.now() * settings.speed * 0.001;
    const points = settings.complexity;

    ctx.strokeStyle = settings.color;
    ctx.lineWidth = 2;
    ctx.beginPath();

    for (let i = 0; i < points; i++) {
      const x = width * 0.5 + Math.cos(time + i * 0.1) * (100 + Math.sin(time * 0.5) * 50);
      const y = height * 0.5 + Math.sin(time + i * 0.1) * (100 + Math.cos(time * 0.5) * 50);
      
      if (i === 0) {
        ctx.moveTo(x, y);
      } else {
        ctx.lineTo(x, y);
      }
    }

    ctx.stroke();
  }, [settings]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d')!;
    let animationId: number;

    const animate = () => {
      if (isPlaying) {
        generateArt(ctx);
        animationId = requestAnimationFrame(animate);
      }
    };

    if (isPlaying) {
      animate();
    }

    return () => {
      cancelAnimationFrame(animationId);
    };
  }, [isPlaying, generateArt]);

  const handleDownload = () => {
    if (!canvasRef.current) return;
    const link = document.createElement('a');
    link.download = 'generative-art.png';
    link.href = canvasRef.current.toDataURL();
    link.click();
  };

  const handleCanvasClick = () => {
    if (!showControls) return;
    setIsPlaying(!isPlaying);
  };

  return (
    <>
      <canvas 
        ref={canvasRef}
        width={width}
        height={height}
        onClick={handleCanvasClick}
        className={className}
      />
      
      {showControls && (
        <>
          <div className="fixed top-4 right-4 flex gap-4">
            <button 
              onClick={() => setIsPlaying(!isPlaying)}
              className="p-2 hover:bg-white/10 rounded-full transition-colors"
            >
              {isPlaying ? <Pause size={24} /> : <Play size={24} />}
            </button>
            <button 
              onClick={handleDownload}
              className="p-2 hover:bg-white/10 rounded-full transition-colors"
            >
              <Download size={24} />
            </button>
            <button 
              onClick={() => {
                const ctx = canvasRef.current?.getContext('2d');
                if (ctx) generateArt(ctx);
              }}
              className="p-2 hover:bg-white/10 rounded-full transition-colors"
            >
              <RefreshCw size={24} />
            </button>
            <button 
              onClick={() => document.getElementById('settingsPanel')?.classList.toggle('translate-x-full')}
              className="p-2 hover:bg-white/10 rounded-full transition-colors"
            >
              <Settings2 size={24} />
            </button>
          </div>

          <div 
            id="settingsPanel"
            className="fixed right-0 top-0 h-full w-80 bg-black/90 backdrop-blur-lg transform translate-x-full transition-transform duration-300 p-6 border-l border-white/10"
          >
            <h2 className="text-xl font-bold mb-6">Settings</h2>
            <div className="space-y-6">
              <div>
                <label className="block text-sm mb-2">Complexity</label>
                <input 
                  type="range"
                  min="10"
                  max="100"
                  value={settings.complexity}
                  onChange={(e) => setSettings({...settings, complexity: parseInt(e.target.value)})}
                  className="w-full"
                />
              </div>
              <div>
                <label className="block text-sm mb-2">Speed</label>
                <input 
                  type="range"
                  min="0.1"
                  max="2"
                  step="0.1"
                  value={settings.speed}
                  onChange={(e) => setSettings({...settings, speed: parseFloat(e.target.value)})}
                  className="w-full"
                />
              </div>
              <div>
                <label className="block text-sm mb-2">Color</label>
                <input 
                  type="color"
                  value={settings.color}
                  onChange={(e) => setSettings({...settings, color: e.target.value})}
                  className="w-full h-10 bg-transparent border border-white/10 rounded"
                />
              </div>
            </div>
          </div>
        </>
      )}
    </>
  );
}