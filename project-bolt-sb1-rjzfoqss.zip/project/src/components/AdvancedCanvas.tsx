import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Settings2, Download, RefreshCw, Play, Pause } from 'lucide-react';

interface AdvancedCanvasProps {
  width: number;
  height: number;
  className?: string;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  life: number;
}

// Perlin noise implementation
const p = Array.from({ length: 512 }, (_, i) => i < 256 ? i : i - 256)
  .sort(() => Math.random() - 0.5);

const fade = (t: number) => t * t * t * (t * (t * 6 - 15) + 10);

const lerp = (t: number, a: number, b: number) => a + t * (b - a);

const grad = (hash: number, x: number, y: number) => {
  const h = hash & 15;
  const u = h < 8 ? x : y;
  const v = h < 4 ? y : h === 12 || h === 14 ? x : 0;
  return ((h & 1) === 0 ? u : -u) + ((h & 2) === 0 ? v : -v);
};

export default function AdvancedCanvas({ width, height, className = '' }: AdvancedCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isPlaying, setIsPlaying] = useState(true);
  const [settings, setSettings] = useState({
    noiseScale: 0.005,
    particleCount: 1000,
    flowStrength: 2,
    colorMode: 'rainbow',
    complexity: 3,
    turbulence: 0.5,
  });

  const particles = useRef<Particle[]>([]);
  const frame = useRef(0);

  const createParticle = useCallback(() => {
    const x = Math.random() * width;
    const y = Math.random() * height;
    const hue = Math.random() * 360;
    
    return {
      x,
      y,
      vx: 0,
      vy: 0,
      size: Math.random() * 2 + 1,
      color: `hsla(${hue}, 100%, 50%, 0.1)`,
      life: Math.random() * 200 + 50
    };
  }, [width, height]);

  const noise2D = useCallback((x: number, y: number) => {
    const X = Math.floor(x) & 255;
    const Y = Math.floor(y) & 255;
    
    x -= Math.floor(x);
    y -= Math.floor(y);
    
    const u = fade(x);
    const v = fade(y);
    
    const A = p[X] + Y;
    const B = p[X + 1] + Y;
    
    return lerp(
      v,
      lerp(u, grad(p[A], x, y), grad(p[B], x - 1, y)),
      lerp(u, grad(p[A + 1], x, y - 1), grad(p[B + 1], x - 1, y - 1))
    );
  }, []);

  const updateParticle = useCallback((particle: Particle) => {
    const angle = noise2D(
      particle.x * settings.noiseScale,
      particle.y * settings.noiseScale
    ) * Math.PI * settings.complexity + frame.current * 0.01;

    particle.vx += Math.cos(angle) * settings.flowStrength;
    particle.vy += Math.sin(angle) * settings.flowStrength;

    const speed = Math.sqrt(particle.vx * particle.vx + particle.vy * particle.vy);
    if (speed > settings.flowStrength) {
      particle.vx = (particle.vx / speed) * settings.flowStrength;
      particle.vy = (particle.vy / speed) * settings.flowStrength;
    }

    particle.x += particle.vx;
    particle.y += particle.vy;
    particle.life--;

    if (
      particle.x < 0 || particle.x > width ||
      particle.y < 0 || particle.y > height ||
      particle.life <= 0
    ) {
      Object.assign(particle, createParticle());
    }
  }, [settings, width, height, createParticle, noise2D]);

  const animate = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d')!;
    ctx.fillStyle = 'rgba(255, 255, 255, 0.01)';
    ctx.fillRect(0, 0, width, height);

    particles.current.forEach(particle => {
      updateParticle(particle);
      ctx.fillStyle = particle.color;
      ctx.beginPath();
      ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
      ctx.fill();
    });

    frame.current++;
  }, [width, height, updateParticle]);

  useEffect(() => {
    particles.current = Array.from(
      { length: settings.particleCount },
      createParticle
    );
  }, [settings.particleCount, createParticle]);

  useEffect(() => {
    let animationId: number;

    const loop = () => {
      if (isPlaying) {
        animate();
        animationId = requestAnimationFrame(loop);
      }
    };

    if (isPlaying) {
      loop();
    }

    return () => {
      cancelAnimationFrame(animationId);
    };
  }, [isPlaying, animate]);

  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const link = document.createElement('a');
    link.download = 'unknown-algo-art.png';
    link.href = canvas.toDataURL('image/png');
    link.click();
  };

  return (
    <div className="relative">
      <canvas
        ref={canvasRef}
        width={width}
        height={height}
        className={className}
      />
      
      <div className="absolute top-4 right-4 flex gap-4">
        <button 
          onClick={() => setIsPlaying(!isPlaying)}
          className="p-2 bg-white hover:bg-gray-100 rounded-full transition-colors shadow-md"
        >
          {isPlaying ? <Pause size={24} /> : <Play size={24} />}
        </button>
        <button 
          onClick={handleDownload}
          className="p-2 bg-white hover:bg-gray-100 rounded-full transition-colors shadow-md"
        >
          <Download size={24} />
        </button>
        <button 
          onClick={() => {
            particles.current = Array.from(
              { length: settings.particleCount },
              createParticle
            );
          }}
          className="p-2 bg-white hover:bg-gray-100 rounded-full transition-colors shadow-md"
        >
          <RefreshCw size={24} />
        </button>
        <button 
          onClick={() => document.getElementById('settingsPanel')?.classList.toggle('translate-x-full')}
          className="p-2 bg-white hover:bg-gray-100 rounded-full transition-colors shadow-md"
        >
          <Settings2 size={24} />
        </button>
      </div>

      <div 
        id="settingsPanel"
        className="fixed right-0 top-0 h-full w-80 bg-white shadow-lg transform translate-x-full transition-transform duration-300 p-6 border-l border-gray-200"
      >
        <h2 className="text-xl font-bold mb-6">Settings</h2>
        <div className="space-y-6">
          <div>
            <label className="block text-sm mb-2">Particle Count</label>
            <input 
              type="range"
              min="100"
              max="5000"
              value={settings.particleCount}
              onChange={(e) => setSettings({...settings, particleCount: parseInt(e.target.value)})}
              className="w-full"
            />
          </div>
          <div>
            <label className="block text-sm mb-2">Flow Strength</label>
            <input 
              type="range"
              min="0.1"
              max="5"
              step="0.1"
              value={settings.flowStrength}
              onChange={(e) => setSettings({...settings, flowStrength: parseFloat(e.target.value)})}
              className="w-full"
            />
          </div>
          <div>
            <label className="block text-sm mb-2">Complexity</label>
            <input 
              type="range"
              min="1"
              max="10"
              step="0.1"
              value={settings.complexity}
              onChange={(e) => setSettings({...settings, complexity: parseFloat(e.target.value)})}
              className="w-full"
            />
          </div>
          <div>
            <label className="block text-sm mb-2">Turbulence</label>
            <input 
              type="range"
              min="0"
              max="1"
              step="0.01"
              value={settings.turbulence}
              onChange={(e) => setSettings({...settings, turbulence: parseFloat(e.target.value)})}
              className="w-full"
            />
          </div>
        </div>
      </div>
    </div>
  );
}