import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { Github } from 'lucide-react';
import Home from './pages/Home';
import Create from './pages/Create';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-white text-gray-900">
        <header className="fixed top-0 w-full bg-white/90 backdrop-blur-sm border-b border-gray-200 z-10">
          <div className="container mx-auto px-4 py-4 flex justify-between items-center">
            <div className="flex items-center gap-8">
              <Link to="/" className="text-xl font-medium">The Unknown Algo</Link>
              <nav className="hidden md:flex gap-6">
                <Link to="/" className="hover:text-gray-600 transition-colors">Home</Link>
                <Link to="/create" className="hover:text-gray-600 transition-colors">Create</Link>
              </nav>
            </div>
            <a 
              href="https://github.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <Github size={20} />
            </a>
          </div>
        </header>

        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/create" element={<Create />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;