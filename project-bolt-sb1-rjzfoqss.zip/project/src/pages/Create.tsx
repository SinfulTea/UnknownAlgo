import React, { useState } from 'react';
import { Wallet, Download, RefreshCw } from 'lucide-react';
import AdvancedCanvas from '../components/AdvancedCanvas';

export default function Create() {
  const [isWalletConnected, setWalletConnected] = useState(false);

  const connectWallet = async () => {
    if (typeof window.ethereum !== 'undefined') {
      try {
        await window.ethereum.request({ method: 'eth_requestAccounts' });
        setWalletConnected(true);
      } catch (error) {
        console.error('User rejected wallet connection');
      }
    } else {
      alert('Please install MetaMask to use this feature');
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <main className="container mx-auto px-4 pt-24 pb-16">
        <div className="max-w-4xl mx-auto">
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-3xl font-bold">Create Your Art</h1>
            <button
              onClick={connectWallet}
              className="flex items-center gap-2 px-4 py-2 bg-black text-white rounded-lg hover:bg-gray-800 transition-colors"
            >
              <Wallet size={20} />
              {isWalletConnected ? 'Connected' : 'Connect Wallet'}
            </button>
          </div>
          
          <AdvancedCanvas 
            width={800}
            height={800}
            className="w-full aspect-square border border-gray-200 rounded-lg shadow-lg"
          />
        </div>
      </main>
    </div>
  );
}