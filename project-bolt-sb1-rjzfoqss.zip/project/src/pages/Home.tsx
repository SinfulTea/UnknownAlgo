import React from 'react';
import { Link } from 'react-router-dom';
import Canvas from '../components/Canvas';

export default function Home() {
  return (
    <main className="container mx-auto px-4 pt-24 pb-16 max-w-3xl">
      <article className="prose prose-lg">
        <h1 className="text-4xl font-bold mb-8">The Unknown Algo</h1>
        
        <p className="text-xl text-gray-600 mb-12">
          A generative art NFT project by SinfulTea and ODgm.
        </p>

        <div className="my-12">
          <Link to="/create">
            <Canvas 
              width={800}
              height={800}
              showControls
              className="w-full aspect-square border border-gray-200 rounded-lg hover:border-gray-300 transition-colors"
            />
          </Link>
        </div>

        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-4">Introduction</h2>
          <p>
            The Unknown Algo is a generative art project that explores the intersection of human curation and algorithmic creation. 
            The system generates unique pieces based on various parameters, allowing collectors to participate in the 
            creative process.
          </p>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-4">The Algorithm</h2>
          <p>
            At its core, The Unknown Algo uses a custom algorithm that generates flowing, organic forms through mathematical functions 
            and carefully tuned parameters. The algorithm creates pieces that balance between chaos and order, producing 
            works that feel both natural and intentional.
          </p>
          <div className="my-8 grid grid-cols-2 gap-4">
            <Canvas 
              width={400}
              height={400}
              autoPlay={true}
              className="w-full aspect-square border border-gray-200 rounded-lg"
            />
            <Canvas 
              width={400}
              height={400}
              autoPlay={true}
              className="w-full aspect-square border border-gray-200 rounded-lg"
            />
          </div>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-4">Parameters and Variation</h2>
          <p>
            Each piece is controlled by a set of parameters that influence its final form. These include:
          </p>
          <ul className="list-disc pl-6 mt-4">
            <li>Particle Count: Controls the density of particles in the system</li>
            <li>Flow Strength: Affects how strongly particles follow the flow field</li>
            <li>Complexity: Determines the intricacy of the generated patterns</li>
            <li>Turbulence: Adds chaos and unpredictability to the movement</li>
          </ul>
        </section>

        <section className="mb-12">
          <div className="bg-gray-50 border border-gray-200 rounded-lg p-8 text-center">
            <h2 className="text-2xl font-bold mb-4">Start Creating</h2>
            <p className="mb-6">
              Ready to create your own unique piece? Head to the create page to experiment with the algorithm.
            </p>
            <Link 
              to="/create"
              className="inline-block px-6 py-3 bg-black text-white rounded-lg hover:bg-gray-800 transition-colors"
            >
              Create Now
            </Link>
          </div>
        </section>
      </article>
    </main>
  );
}